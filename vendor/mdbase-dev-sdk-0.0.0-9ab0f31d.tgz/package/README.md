# @mdbase-dev/sdk

The TS SDK for mdbase-next replicas. It implements the client side of
`docs/contracts/replica-client-api.md` and is what web apps, Obsidian plugins and
scripts use instead of today's `@mdbase-dev/connect`.

The SDK implements transport, session and typed client-API boundaries.

## Layout

| Path | What |
|---|---|
| `src/cbor.ts` | Strict `mdb-cbor/1` codec (00-overview §3.2): the TS twin of `crates/wire/src/cbor.rs` |
| `src/codec.ts` | Typed struct/union/enum codecs, the TS twin of `crates/wire/src/schema.rs` |
| `src/wire.ts` | Client API messages and operations, typed (mirrors `crates/wire/src/client.rs`, `intent.rs`) |
| `src/errors.ts` | The 15 error codes and `MdbaseError` (§9) |
| `src/transport/noise.ts` | `Noise_IK_25519_ChaChaPoly_SHA256` for local IPC and relay sessions (§12.2, §12.3) |
| `src/session.ts`, `src/client.ts` | One session (frames, cancel, pushes); `MdbaseClient` (reads, live queries, writes, receipts, status, holds, conflicts, fence, reconnect) |
| `src/files.ts`, `src/presence.ts` | Files (§10) and presence (§11) |
| `src/view-sources.ts` | Shared saved-view source create/update helpers over ordinary record intents |
| `src/records.ts`, `src/records/` | Shared record editor leases, bounded drafts and exact receipt recovery |
| `src/private.ts` | Device approval and recovery key (private collections) |
| `src/keys.ts` | Client static keys: non-extractable WebCrypto X25519 in IndexedDB where possible |
| `src/transport/port.ts` | The transport seam: `FramePort`, `Connector`, `u32be` record framing |
| `src/transport/inprocess.ts` | In-process connector to a shared runtime (§12.1) |
| `src/transport/noise-session.ts` | Noise sessions over message carriers (WebSocket, `u16be`-framed streams) |
| `src/transport/relay.ts` | Relay / hosted replica connector (§12.3) |
| `src/node.ts` (`@mdbase-dev/sdk/node`) | Local IPC to the daemon (§12.2) |
| `src/testing/` (`@mdbase-dev/sdk/testing`) | `MemoryReplica` (in-memory replica speaking the protocol) and `serveNoise` |
| `test/golden.test.ts` | Runs every fixture in `conformance/wire/` from TS |

## Value model

What the SDK hands to apps, following §12.1:

| CBOR | TS |
|---|---|
| integer within ±(2^53−1) | `number` |
| integer beyond that | `bigint` |
| float with a fractional part | `number` |
| integral float (`1.0`, `-0.0`) | `Float64` (so `1` and `1.0` stay distinct) |
| byte string | `Uint8Array` |
| data map (text keys, order is data) | `Map<string, …>` |
| struct map | `Map<number, …>` at the raw level; named-field objects in the typed layer |

In the typed layer, UUIDs are canonical lowercase strings, hashes are `sha256:<hex>`
revision tokens, and enumerations are their snake_case names.

## Usage

```ts
import { connect, relayConnector, loadOrCreateClientKey } from "@mdbase-dev/sdk";

const key = await loadOrCreateClientKey("my-app");          // register key.publicKey with the grant
const db = await connect({
  app: { name: "my-app", version: "1.0.0" },
  connector: relayConnector({ collection, grant, staticKey: key, resolveRoute }),
  waitForDevice: true,                                       // private collections
});

const tasks = db.live({ types: ["task"], order_by: ["-due"], limit: 200 });   // windowed, no bodies
tasks.subscribe((s) => render(s.records, { stale: s.stale, complete: s.complete }));

const rec = await db.get(id, { body: true });
const w = await db.update(rec, { patch: { status: "done" }, body: edited }); // base + body edits filled in
w.records;                    // optimistic view now
await w.confirmed;            // at a log position, or throws MdbaseError (15 codes)

db.onStatus((s) => show(`Synced through ${s.confirmedThrough}` + (s.pending ? `, ${s.pending} waiting` : "")));
```

## Record editor leases

```ts
const lease = await db.records.open({path: "notes/writing.md"}, {
  autosave: {idleMs: 500}, // omitted/false means explicit flush only
  signal,
});
const stop = lease.session.subscribe(() => render(lease.session.getSnapshot()));
lease.session.setBody(editedBody);
lease.session.patchFrontmatter({title: "New title"}); // undefined unsets a key
const result = await lease.session.flush({timeoutMs: 30_000, signal});
if (!result.ok) showProblem(result.problem);
stop();
lease.release();
```

UUIDs and `{path}` selectors use ordinary native `get`/`update` operations. Full
native document/body/revision and current protection gates are required; edits
use the actual source's whole-document CAS, field observations and body base.
There is no source reconstruction, replacement record UUID or new app database.
`records.open` throws SDK errors; `flush` returns `{ok, record}` or `{ok, problem}`.
Snapshots retain exact SDK value maps, native `record`/`remote`, draft `body`,
`dirty`, `problem`, and the original `recovery` mutation identity/receipt/`Write`.
Saved requires actual confirmed, unprotected, same-UUID full native readback;
receipt confirmation alone (or optimistic/pending readback) is insufficient.

Submission is serialized per UUID/client. A mutation ID is exposed through the
snapshot **before** submission. Ambiguous submit/readback failures keep that ID;
subsequent flush only awaits its actual receipt, never resubmits or substitutes
another mutation. New edits made during capture remain drafts for a subsequent
intent only after the first has genuinely settled. A unique pending operation
from this client's native pending API can recover an editor session; foreign or
ambiguous pending ownership refuses. Across client lifetime/reload, retain the
snapshot's `RecordRecoveryRef` (`mutationId`, `recordId`, `baseRevision`) in the
caller-owned recovery state and pass it as `open(..., {recovery})`, particularly
when the receipt settled but readback failed. The helper adds no durable journal
and does not infer ownership from a shared current pending record.

Active leases share the UUID's draft/session and must agree on autosave/timeout
policy. Releasing/aborting one lease unsubscribes it without closing the client
or evicting another lease. Last release stops autosave/observation and aborts
late delivery, retaining unsaved/recovering data for reopen on the same client.
Client close suspends all leases. Retention is bounded to 64 sessions and 8 MiB
of serialized retained-data accounting; budget refusal never evicts drafts.
This accounting is not a measured peak-heap claim.

For a settled CAS conflict, `resolve({keep: "mine" | "theirs"})` or
`resolve({body})` explicitly rebases on a genuine confirmed/unprotected remote
readback. Native held/unresolved records remain refused: the current native
hold-resolution producer lacks caller-captured mutation identity and cancellation,
so this helper cannot safely resolve a hold or retry its unknown outcome. It does
not use a fresh `resolveHold` call as a workaround. Change notifications hydrate
the same UUID; observer failure is exposed, not treated as a successful refresh.

## Classic-script browser bundle

`npm run build` includes `dist/browser/mdbase-sdk.js` and
`dist/browser/mdbase-sdk.min.js` in the SDK archive. Serve the exact qualified
archive's asset from your app's origin; no CDN publication is implied.

```html
<script src="./vendor/mdbase-sdk.min.js"></script>
<script>
  const { connect, Client, AppHost } = window.MdbaseSDK;
  // Root exports match @mdbase-dev/sdk; Client groups client.ts exports.
  // AppHost matches @mdbase-dev/sdk/app-host.
</script>
```

Module consumers can import the same surface from `@mdbase-dev/sdk/browser`.
There is no `MdbaseConnect` compatibility shim or app-specific adapter. Loading
this bundle does not create a session, open storage, load a WASM runtime or grant
access. App-host APIs still require explicit qualified app/environment trust,
runtime, origin and custody inputs. This package does not supply a complete web
Worker/session/runtime composition; use the shared SDK composition when available,
not an app-specific substitute. Packaging tests are not sign-in, CRUD, custody,
physical durability or release-qualification evidence.

## Saved-view sources

`db.views.createSource({id, path, document, type?}, {mutationId, ...writeOptions})`
creates the exact caller-supplied source. Capture and retain the record UUID and
mutation UUID before submitting (the SDK exports `uuidv7`). No renderer, record
type, filename extension or YAML is inferred or rewritten.

`db.views.getSourceRecord(ref, {include?, signal?})` requests a complete native
record with its document included. `db.views.updateSource(seen, document,
{mutationId, ...writeOptions})` uses that genuine `RecordView`'s UUID, path, full
source and revision for whole-document CAS. Pending revisions are valid; held,
unresolved, metadata-only or inconsistent source witnesses refuse. A new edit
needs its own captured mutation UUID, not a replacement for an unknown outcome.

Both write helpers return the original SDK `Write`, force document-inclusive
readback, and preserve receipt IDs, confirmation and publication separately.
Neither performs an implicit refresh or prepares/resubmits on unknown outcomes.
The ordinary client transport's same-mutation retry policy is unchanged.

For **web app-host** saved-view discovery/execution/exact source reads, use
`listAppBasesViews`, `executeAppBases` and `readAppBasesViewSource`, with the types
from `@mdbase-dev/sdk/app-host`. Keep native UUID/SHA/original ordinal and actual
source options. The generic `views.list/execute/readSource` RPC surface is not an
app-host fallback; unavailable capabilities remain explicit refusals.

## Shared read helpers

```ts
const records = await db.readMany(refs, { effective: true }, signal, {
  concurrency: 8,
});
for await (const page of db.queryPages(query, include, signal)) {
  displayPage(page); // retains complete/asOf/diagnostics, not only records
}
```

`readMany(refs, include?, signal?, options?)` makes ordinary `get` calls and
returns genuine `RecordView` values in input order. Duplicate selections retain
separate calls and output slots. Up to 1000 selections are allowed; concurrency
is an integer 1..16 (default 8). Path selectors must be nonempty and at most
4096 UTF-8 bytes. UUIDs (including a supplied view's UUID), paths, Include and
concurrency are captured before the first await. A view's old path/revision is
not asserted current and a partial input is never promoted to a native witness.

Missing/refused/error reads fail the entire batch with the first observed error,
not omitted rows or partial success. Scheduling stops; already-started reads
settle before that error is delivered. The original signal fences dispatch and
final delivery, including late backend replies. There is no helper-level retry,
refresh, fallback, replacement identity or cancellation of the caller's signal;
the ordinary SDK `get` transport policy is unchanged. Request/in-flight bounds
are not a peak-heap or returned-byte budget. Use explicit Include and bounded
selections when hydrating bodies/documents. Multiple gets are **not a single
native snapshot**; callers still check identity/source-revision witnesses.

`queryPages(query, include?, signal?, options?)` delegates **exactly** to `pages`
and returns the same whole-page iterator. No records are flattened and no reset
is added. Root exports `readMany(client, ...)`, `queryPages(client, ...)` and
`ReadManyOptions` are also available.

Feature negotiation already uses explicit `connect({ features: [...] })` and
`client.hello.features`. A factory-owned client should retain the requested list
alongside the negotiated list so **not requested** is distinguishable from
**requested but not negotiated**. An absent unrequested feature is not evidence
of unsupported functionality; `describe()` describes catalogue/types/settings,
not feature availability. The hello grant snapshot is not current authorization:
ordinary native RPC reauthorization remains authoritative. These helpers add no
feature probe, private RPC or implicit scope expansion.

## People and canonical contract inspection

```ts
import { MdbasePeopleClient } from "@mdbase-dev/sdk";
// Inside the trusted owned Worker, after collection adoption and CP transport pinning.
// host is the existing AppWebCloudCopyHost; its session/credential stays private.
const metadata = host.peopleAuthority();
const people = new MdbasePeopleClient(db, metadata);
const directory = await people.directory({ members: "if-approved", signal });
directory.account; // public exact issuer/subject/name/account UUID
directory.me;      // linked, unlinked, ambiguous, or invalid; never name/email inference
directory.people;  // complete native mdbase.person 2.0.0 inventory
// host.close() retires metadata before native/SQL shutdown.
```

The host returns only a frozen read-only metadata view, not a session or bearer
getter. Send only public directory projections over the Worker channel. Other
trusted hosts owning a genuine registered-device session can construct
`AppCpPeopleAuthority` internally; callers must never reconstruct it from receipts.

`current()` and `members()` read fixed CP metadata endpoints; `directory()` uses
Core's canonical resolved mappings, defaults and validation through
`db.queryContract({ id, version }, { pageSize, cursor, signal })`. It does not
recreate contract semantics from raw frontmatter. The directory checks CP/native
collection binding and consumes every native continuation under one session,
`asOf` and contract digest; stale/incomplete/oversized inventories fail as a whole.
A full unindexed window refuses with `contract_query_cursor_required`, not a
fabricated cursor or partial result. A fresh absent registered Person contract
means unlinked; disappearance after any page is an error. Invalid claiming
records take precedence over an otherwise linked match. Optional members are
omitted only for explicit permission decline (or `members: "omit"`), never scope,
revocation, integrity or network errors. Old producers refuse the additive
version-one method, without an SDK projection fallback. No record path/payload
or key is sent to the metadata authority.

## Query cursor resets

`pages(query, include?, signal?, options?)` repeats the original query with the
replica's opaque cursor. By default, typed `invalid_request/fix_request` reasons
`cursor_expired` and `cursor_stale` are thrown unchanged. There is no offset
fallback or automatic mixing of already-yielded pages with a fresh query.

To opt in to **one restart per iterator**, clear your accumulated/displayed
paging state in the awaited `onReset` callback:

```ts
for await (const page of db.pages(query, include, signal, {
  onReset: async ({ reason, pagesYielded, signal }) => {
    await clearDisplayedPages(); // completes BEFORE the fresh first-page RPC
  },
})) {
  displayPage(page);
}
```

Reset clears all earlier pages even if expiry keeps the same `asOf`. The SDK
strips the cursor and preserves the captured original offset, limit, query and
include on restart. Callback failure, cancellation, or a second cursor refusal
stops the iterator. Malformed/foreign/conflicting cursors, READ denial and other
errors never trigger this callback. Native cursor lifetime/clock/head guarantees
remain the replica's responsibility; these SDK tests do not qualify that producer.

## Static key custody

Browser extensions should explicitly require non-extractable custody **before consent**:

```ts
const key = await loadOrCreateClientKey("reader", {
  storage: indexedDbKeyStorage("reader-keys"),
  requireNonExtractable: true,
});
```

Import `indexedDbKeyStorage` from the SDK. Unsupported X25519 or an existing
raw/extractable identity fails closed; existing identities are never silently
replaced. Reauthorization must be explicit. Without this option, the legacy raw
fallback remains available. Non-extractability does not prevent compromised
extension code from using DH, and is not hardware-backed custody.

Built-in stores return only committed identities and atomically choose one
first-creation winner. Custom persistent stores shared across contexts must
implement `KeyStorage.putIfAbsent`; same-store in-process creation is coalesced.
Keep the key in the extension origin, not a content script or unrestricted DH bridge.

`PLAYWRIGHT_MODULE=<module> CHROMIUM_EXECUTABLE=<browser> node scripts/keys-mv3-smoke.mjs`
runs the actual SDK in a fresh isolated MV3 profile: page/worker races, export
refusal, real DH, existing-key refusal, late IDB abort, worker wake and browser reopen.

## Checks

```sh
npm ci && npm run typecheck && npm test && npm run build && npm run size   # or: cargo xtask sdk
```
